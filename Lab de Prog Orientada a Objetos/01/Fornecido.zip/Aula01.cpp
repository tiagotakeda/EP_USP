//FACA OS INCLUDES NECESARIOS


//IMPLEMENTE AS FUNCOES
// EXERCICIO 1
/*
int calculaPontuacao(int posicao, bool participou) {
}
*/

// EXERCICIO 2
/*
int calculaPontuacaoFinal(int posicoes[], bool participou[], int quantidade) {
}
*/

// EXERCICIO 3
/*
bool nomesIguais(string nomes[], int quantidade) {
}
*/

/* COMENTE A MAIN PARA SUBMETER */
int main() {

  cout<<calculaPontuacao(3,true);
    return 0;
}
//*/
