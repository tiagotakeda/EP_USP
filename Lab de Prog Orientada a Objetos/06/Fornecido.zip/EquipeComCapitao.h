// Adicione aqui as diretivas de compilacao necessarias

#ifndef EQUIPECOMCAPITAO_H
#define EQUIPECOMCAPITAO_H

using namespace std;

class EquipeComCapitao {
private:
    // Adicione aqui os atributos necessarios

public:
    EquipeComCapitao(string nome, int membros, string nomeCapitao);
    ~EquipeComCapitao();

    string getNomeCapitao();
};

#endif // EQUIPECOMCAPITAO_H
