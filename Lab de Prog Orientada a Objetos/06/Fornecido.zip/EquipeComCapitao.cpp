#include "EquipeComCapitao.h"

using namespace std;

// Implemente aqui os metodos
