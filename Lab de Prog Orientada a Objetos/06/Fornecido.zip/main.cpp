// Inclua aqui as diretivas de compilacao necessarias
using namespace std;

int main() {
    //Teste aqui o seu codigo
}
