#include "Competicao.h"

using namespace std;

// Implemente aqui os metodos necessarios
