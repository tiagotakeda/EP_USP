#ifndef PARTICIPANTE_H
#define PARTICIPANTE_H
#include <string>

using namespace std;

class Participante {
public:
    Participante(string nome);
    virtual ~Participante();

    virtual void imprimir();
    virtual string getNome();
    /* Crie os atributos necessarios */
};

#endif // PARTICIPANTE_H
