#ifndef EQUIPE_H
#define EQUIPE_H
#include <string>
#include <iostream>

using namespace std;

class Equipe {
public:
    Equipe(string nome, int maxValor);
    virtual ~Equipe();

    virtual bool adicionar(int nusp);
    virtual int* getPessoas();

private:
    string nome;
    int maxValor;
    int quantidade;
    int* nusps;
};

#endif // EQUIPE_H
