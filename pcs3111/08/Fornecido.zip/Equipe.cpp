#include "Equipe.h"

Equipe::Equipe(string nome, int maxValor) :
nome(nome), maxValor(maxValor) {
    nusps = new int[maxValor];
}

Equipe::~Equipe() {
	delete[] nusps;
}

bool Equipe::adicionar(int nusp) {
    if(quantidade >= maxValor) return false;
    for(int i = 0; i < quantidade; i++) {
        if(nusps[i] == nusp) return false;
    }
    nusps[quantidade] = nusp;
    quantidade++;
    return true;
}

int* Equipe::getPessoas() {
    return nusps;
}
