#include <iostream>

using namespace std;

int main() {
    /* Faca os testes necessarios */
    return 0;
}
