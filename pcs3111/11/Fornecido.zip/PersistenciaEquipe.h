#ifndef PERSISTENCIAEQUIPE_H
#define PERSISTENCIAEQUIPE_H

// inclua aqui as diretivas de compilacao necessarias

using namespace std;

class PersistenciaEquipe {
private:
    //inclua aqui os atributos necessarios

public:
    PersistenciaEquipe(string arquivo);
    virtual ~PersistenciaEquipe();

    void inserir(Equipe *e);
};
#endif // PERSISTENCIAEQUIPE_H
