#include "Modalidade.h"

Modalidade::Modalidade(string nome, int maximoEquipes) :
        nome(nome), maximoEquipes(maximoEquipes) {
    quantidade = 0;
    equipes = new Equipe*[maximoEquipes];
}

Modalidade::~Modalidade() {
    delete[] equipes;
}

bool Modalidade::adicionar(Equipe* e) {
    if(quantidade >= maximoEquipes)
        return false;
    equipes[quantidade] = e;
    quantidade++;
    return true;
}


string Modalidade::getNome() {
    return nome;
}

int Modalidade::getQuantidade() {
    return quantidade;
}

void Modalidade::imprimir() {
    for(int i = 0; i < quantidade; i++) {
        equipes[i]->imprimir();
    }
}
