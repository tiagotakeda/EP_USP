// FACA OS INCLUDES NECESSARIOS

string* encontrarOponente(string nomes[], int membros[], int quantidade, string nomeEquipe, int membrosEquipe) {
    // IMPLEMENTE A FUNCAO
}

/* COMENTE A MAIN PARA SUBMETER */
int main() {
    // FACA TESTES NA MAIN
    return 0;
}
//*/