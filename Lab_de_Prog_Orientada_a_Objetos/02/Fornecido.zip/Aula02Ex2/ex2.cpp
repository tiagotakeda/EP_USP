// FACA OS INCLUDES NECESSARIOS

int calcularEstatisticas (int membros[], int quantidade, int* minimo, int& maximo) {
    // IMPLEMENTE A FUNCAO
}

/* COMENTE A MAIN PARA SUBMETER */
int main() {
    // FACA TESTES NA MAIN
    return 0;
}
//*/