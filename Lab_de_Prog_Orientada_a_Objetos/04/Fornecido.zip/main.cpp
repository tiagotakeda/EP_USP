#include <iostream>

using namespace std;

class Equipe {
    string nome;
    int numeroDeMembros = 0;

    string getNome();
    int getNumeroDeMembros();
    void setNome(string nome);
    void setNumeroDeMembros(int membros);

    int getMaximoDeTorcedores();
    void imprimir();
};

string Equipe::getNome() {
    return nome;
}

int Equipe::getNumeroDeMembros() {
    return numeroDeMembros;
}

void Equipe::setNome(string nome) {
    this->nome = nome;
}

void Equipe::setNumeroDeMembros(int membros) {
    numeroDeMembros = membros;
}

int Equipe::getMaximoDeTorcedores() {
    return (15 + 25 * numeroDeMembros);
}

void Equipe::imprimir() {
    cout << nome << " - " << numeroDeMembros << " membros" << endl;
}

/**
 * Faca os testes necessarios
 **/
int main() {
    return 0;
}
